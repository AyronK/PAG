#include "Material.hpp"
#include "Texture.hpp"
#include "Mesh.hpp"

using namespace std;


Material::Material()
{
}


Material::~Material()
{
}
