#define SCREEN_WIDTH 1920
#define SCREEN_HEIGHT 1080
#define BACKGROUND_COLOR 0.2f, 0.3f, 0.3f, 1.0f
#define WINDOWS_NAME "WINDOW GL"
#define GL_VERTEX_SHADER_PATH "../Shaders/basic.vert"
#define GL_FRAGMENT_SHADER_PATH "../Shaders/basic.frag"