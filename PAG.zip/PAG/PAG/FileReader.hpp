#include <string>
#include <fstream>
class FileReader
{
public:
	static std::string readFile(std::string fileName);
};